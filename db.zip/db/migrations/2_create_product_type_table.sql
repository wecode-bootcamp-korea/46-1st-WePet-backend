-- migrate:up
CREATE TABLE products (
  id int NOT NULL AUTO_INCREMENT,
  product_type_code varchar(200) NOT NULL,
  PRIMARY KEY (id)
);

-- migrate:down
DROP TABLE product_type
