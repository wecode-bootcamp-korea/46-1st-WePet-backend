-- migrate:up
CREATE TABLE pets (
  id int NOT NULL AUTO_INCREMENT,
  pet_type_code varchar(200) NOT NULL,
  PRIMARY KEY (id)
);

-- migrate:down
DROP TABLE pet_type
